﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomotiveReservation
{
    internal class Connection
    {

        public static string ConnectionString = "datasource = 127.0.0.1;port = 3306; username =root; password=; database = automotive";
        public static string IdContent = "";
    }
}
